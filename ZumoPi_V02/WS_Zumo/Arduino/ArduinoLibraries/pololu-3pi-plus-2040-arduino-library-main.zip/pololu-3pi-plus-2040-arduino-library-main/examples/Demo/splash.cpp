#include <Arduino.h>

#define static extern
#define pololu_3pi_plus_splash_bits unused_placeholder; extern const uint8_t pololu3PiPlusSplash
#include "pololu_3pi_plus_splash.h"
