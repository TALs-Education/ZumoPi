extern const uint8_t pololu3PiPlusSplash[1024];

