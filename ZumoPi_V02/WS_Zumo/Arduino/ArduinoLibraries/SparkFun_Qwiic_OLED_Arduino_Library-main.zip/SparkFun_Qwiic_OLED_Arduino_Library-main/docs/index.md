Placeholder file for index redirect functionality.
