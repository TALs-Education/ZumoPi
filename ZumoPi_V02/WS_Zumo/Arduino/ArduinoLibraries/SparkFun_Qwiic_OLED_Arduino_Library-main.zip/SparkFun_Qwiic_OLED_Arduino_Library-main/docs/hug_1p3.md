The Qwiic OLED 1.3in has its own [hook-up guide](https://docs.sparkfun.com/SparkFun_Qwiic_OLED_1.3in/).
