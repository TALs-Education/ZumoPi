javascript directory
====================
This folder should contain the files for the custom javascript that is enabled in the product documentation